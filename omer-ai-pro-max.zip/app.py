from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = "omer_ai_secret"

def init_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT,
        premium INTEGER DEFAULT 0
    )
    """)
    conn.commit()
    conn.close()

init_db()

def hash_pw(p):
    return hashlib.sha256(p.encode()).hexdigest()

@app.route("/")
def home():
    if "user" in session:
        return render_template("index.html", user=session["user"])
    return redirect("/login")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        u = request.form["username"]
        p = hash_pw(request.form["password"])

        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        c.execute("INSERT INTO users (username,password) VALUES (?,?)", (u,p))
        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form["username"]
        p = hash_pw(request.form["password"])

        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (u,p))
        user = c.fetchone()
        conn.close()

        if user:
            session["user"] = u
            session["premium"] = user[3]
            return redirect("/")
        return "Hatalı giriş"

    return render_template("login.html")

@app.route("/chat", methods=["POST"])
def chat():
    msg = request.json["message"]
    return jsonify({"reply": "ÖMER AI (demo): " + msg})

@app.route("/premium")
def premium():
    return "Premium sistemi demo"

if __name__ == "__main__":
    app.run(debug=True)
